# CloFix FileVPS vs Incus/LXC — Benchmark and Security Report

Generated: 2026-11-01 13:56

**Status:** Measured results from this host.

The bench and audit scripts now call `clofix-worker fx` (not the old placeholder `clofix-fx` CLI) and use `/var/lib/clofix-filevps/instances/<id>/rootfs-mount`. FileVPS create uses Ubuntu 24.04, a throw-away SSH key, cgroup limits, and Protection Mode off. Density skips guest networking because only SSH host ports 22000–22099 exist.

## 0. Run scope (this collection)

This is a **reduced, non-destructive FileVPS-only** run on the local Docker Desktop Compose worker. It is **not** a dedicated bare-metal compare host and **not** a kernel exploit assessment.

| Item | Value |
| --- | --- |
| Collected | 2026-11-01 07:53–07:55 UTC |
| Host | `clofix-local-worker` (Docker Desktop, kernel `7.0.14-linuxkit`, aarch64) |
| Cores / RAM | 10 / 7934 MB |
| Worker | `clofix-worker 0.1.0`, `CLOFIX_USER_NS=false` (Compose development override) |
| Image | Bundled Ubuntu 24.04 FileVPS rootfs |
| Bench sizes | `N_START=2`, `N_IDLE=2`, `DENSITY_MAX=0`, `SETTLE_S=8` |
| Destructive probes | Not run (`--destructive` off) |
| Incus / LXC | Not installed in this worker — no compare numbers |
| Live fleet left running | `vps-01c09f91ffda`, `vps-1b7ce1e40adf`, `vps-3ab923078227` |
| Agent | `clofix-worker run` stayed up (shared state directory with the local `fx` CLI) |

### How to read these numbers

- Negative idle RAM (`-23.99 MB/VPS`) and negative idle CPU (`-0.22%`) are **host `MemAvailable` / `/proc/stat` jitter**, not a claim that FileVPS uses negative memory. Three customer VPS plus the agent were already on the same worker.
- `projected_idle_density` is `n/a` because measured idle RAM delta was not positive.
- Density count is `0` because `DENSITY_MAX=0` on a worker that already hosts customer VPS. Do not treat that as max packing.
- Isolation FAILs for I01 / I02 / X05 are **expected** with `CLOFIX_USER_NS=false`. Production workers default `user_ns=true`.
- FileVPS guests share the host kernel. They are **not** KVM/QEMU VMs.
- Do not claim Ubuntu/CentOS/Debian/Incus/LXC support from this run. Only FileVPS on linuxkit was measured.
- `N03` matches OverlayFS `lowerdir`/`upperdir` under `/var/lib/clofix-filevps`. That is the guest's own root overlay, not a leaked `docker.sock`.
- `F02` `/tmp` and `/var/tmp` without a sticky bit is a rootfs image issue, not a FileVPS engine escape.
- `O03` `localhost.localdomain` means `--hostname` did not land in `/etc/hostname` for these audit guests.
- `R01`–`R03` FAIL/WARN means the guest could not see `pids.max` / `memory.max` / `cpu.max`. That does not prove the worker skipped host cgroup limits; the probe reads those files from inside the VPS.

## 1. Performance Benchmark

Host: 10 cores, 7934 MB RAM, kernel 7.0.14-linuxkit

| Metric | CloFix FileVPS |
|---|---|
| Create time (median) | 38.0 ms |
| Start → ready (median) | 1,672.5 ms |
| Total launch (median) | 1,710.5 ms |
| Idle RAM overhead / VPS | -24.0 MB |
| Disk / VPS after create | 0.1 MB |
| Disk / VPS running | 0.1 MB |
| Host processes / VPS | 1.0 |
| Kernel memory / VPS (slab+stack+pgtables) | 0.3 MB |
| Process (anon) memory / VPS | 0.5 MB |
| Page cache / VPS (low = shared base OS) | 0.5 MB |
| Rootfs apparent size | 109.5 MB |
| OS share ratio (apparent ÷ real disk; >1 = shared) | 2,335.2x |
| Idle host CPU overhead (all VPS) | -0.2 % |
| In-VPS CPU loop (median) | 852.0 ms |
| Exec latency (median) | 3.0 ms |
| Max VPS reached (test cap) | 0.0 |
| RAM / VPS at max density | — |
| Avg launch time during density | — |
| Projected idle VPS on this host | — |

OS share mode: CloFix FileVPS=shared-inode (hardlink/overlay lower)

Stop reasons (density): CloFix FileVPS=max_reached

_better = FileVPS better by >5%, worse = FileVPS worse by >5%, same = within ±5%. For lower-is-better metrics, a positive percent means FileVPS uses less._

## 2. Security Audit

### Summary (FAIL / WARN / PASS)

| Category | CloFix FileVPS |
|---|---|
| Root isolation | 2 / 3 / 3 |
| Namespace escape | 2 / 1 / 3 |
| Cross-VPS access | 2 / 0 / 4 |
| Filesystem security | 1 / 0 / 4 |
| Resource exhaustion | 2 / 2 / 0 |
| Kernel & OS sharing | 0 / 4 / 4 |
| **Total** | **9 / 10 / 18** |

### Findings — CloFix FileVPS

| Status | ID | Check | Detail |
|---|---|---|---|
| FAIL | I01 | Container root == host root (identity uid_map, no user namespace) |          0          0 4294967295 |
| FAIL | I02 | Dangerous capabilities in container root: SYS_MODULE SYS_RAWIO SYS_BOOT SYS_TIME SYS_PTRACE | CapEff=000001ffffffffff |
| FAIL | N01 | Namespaces shared with host: user cgroup |  |
| FAIL | N03 | Host paths / runtime sockets mounted in container | 345 256 0:81 / / rw,relatime - overlay overlay rw,lowerdir=/var/lib/clofix-filevps/images/cache/ubuntu/24.04/rootfs,upperdir=/var/lib/clofix-filevps/instances/cfxa-fx-a/upper,workdir=/var/lib/clofix-filevps/instances/cfxa-fx-a/work,uuid=on,nouserxattr |
| FAIL | X04 | VPS-A and VPS-B share namespaces: cgroup |  |
| FAIL | X05 | Identity uid mapping — root in A equals root in B on host |  |
| FAIL | F02 | World-writable dirs without sticky bit | /var/tmp /tmp |
| FAIL | R01 | No pids.max visible — fork bomb can exhaust host PIDs | pids.max=n/a |
| FAIL | R02 | No memory limit visible | memory.max=n/a |
| WARN | I03 | No seccomp filter on container init | NoNewPrivs: 0 Seccomp: 0  |
| WARN | I04 | No AppArmor/SELinux confinement |  |
| WARN | I08 | Kernel log readable from container (info leak) | restrict=1 |
| WARN | N05 | Host cgroup path visible to container | 0::/clofix-filevps/cfxa-fx-a |
| WARN | R03 | No CPU quota visible | cpu.max=n/a |
| WARN | R04 | VPS sees ~whole host disk — no visible per-VPS disk quota | vps=474044488KB host=474044488KB |
| WARN | K02 | Host kernel hardening gaps (shared-kernel attack surface): kptr_restrict=0(want 2) unprivileged_bpf_disabled=0(want 2) io_uring_disabled=0(want 2) |  |
| WARN | K05 | VPS /proc/meminfo shows HOST total RAM (leak + apps mis-size caches); consider lxcfs-style view | MemTotal=8124516 kB |
| WARN | K07 | CPU side-channel mitigations missing for: spec_store_bypass  (shared kernel/CPU) | smt= |
| WARN | O03 | VPS-A and VPS-B have identical hostname/identity files ('localhost.localdomain') — per-VPS identity not set |  |
| INFO | K01 | Kernel shared with host (7.0.14-linuxkit) — a kernel bug affects ALL VPSes on this worker |  |
| INFO | K03 | Host allows user namespaces (max=31879) — larger kernel attack surface, but required for uid mapping |  |
| INFO | O04 | OS share: host='ubuntu 24.04' VPS='ubuntu 24.04' (patching host kernel patches all VPSes; VPS userland patched separately) |  |
| SKIP | F06 | Symlink-escape test needs FX_FILE_READ template (control-plane file read) |  |
| SKIP | R10 | Active exhaustion probes skipped (use --destructive) |  |
| PASS | I05 | Sensitive /proc,/sys paths not writable |  |
| PASS | I06 | No /dev/mem,kmem,port or block devices |  |
| PASS | I07 | mount() denied inside container |  |
| PASS | N02 | PID namespace isolated | inside=4 host=51 |
| PASS | N04 | No writable release_agent |  |
| PASS | N06 | /proc/1/root resolves inside container root |  |
| PASS | X01 | VPS-B marker files invisible from VPS-A |  |
| PASS | X02 | Host runtime directories not visible |  |
| PASS | X03 | VPS-B processes invisible from VPS-A |  |
| PASS | X06 | VPS-A cannot reach VPS-B (10.231.0.6) — inter-VPS traffic blocked |  |
| PASS | F01 | SUID binary count acceptable (0) |  |
| PASS | F03 | /etc/shadow mode 640 |  |
| PASS | F04 | VPS dir on host not world-accessible (mode 750) | /var/lib/clofix-filevps/instances/cfxa-fx-a |
| PASS | F05 | mknod of block devices denied |  |
| PASS | K04 | Host-global sysctls not writable (writable namespaced only: none) |  |
| PASS | K06 | Kernel module list hidden |  |
| PASS | O01 | Base OS not hardlink-shared (separate copy / COW / overlay) | A=5120986 B=5120986 |
| PASS | O02 | OS-tree writes in VPS-A do not leak into VPS-B |  |

## 3. FileVPS code-backed expectations

These rows describe what the current worker engine is written to do. They are **not** live measurements.

| ID | Expected | Why (code) | Verification |
|---|---|---|---|
| I01 | PASS when `user_ns=true` | `CLONE_NEWUSER` maps guest 0 to `uid_base` (default 100000) | Unverified on this Mac workspace |
| I02 | WARN or PASS | Guest root in a user namespace often still has scoped `CAP_SYS_ADMIN` | Unverified |
| I03 | PASS | `fx-init` installs a seccomp filter and `no_new_privs` | Unverified |
| I04 | WARN | AppArmor is detected on the host; no per-guest profile is applied | Unverified |
| I05 I06 | PASS | Guest `/dev` is a private tmpfs; mount/kexec/module syscalls are denied | Unverified |
| I07 | PASS | `mount` is in the seccomp deny list | Unverified |
| N01 N02 | PASS | New mount, PID, UTS, IPC, net (and user) namespaces | Unverified |
| N05 | WARN | `CLONE_NEWCGROUP` is not set, so the host cgroup path can remain visible | Unverified |
| X01 X03 X04 | PASS | Separate OverlayFS upper layers and namespaces | Unverified |
| X05 | WARN | Every guest uses the same `uid_base` range | Unverified |
| X06 | PASS | Each veth is `bridge link set isolated on`; nftables default-drop forward | Unverified |
| R01 R02 R03 | PASS | cgroup v2 sets `pids.max`, `memory.max`/`memory.high`, `cpu.max` | Unverified |
| R04 R12 | WARN | `disk_mb` is placement accounting only; no guest quota yet | Unverified |
| K01 | INFO | FileVPS shares the host kernel; it is not KVM/QEMU | Documented |
| O01 O02 | PASS | Shared read-only image + per-guest OverlayFS upper layer | Unverified |

Production workers default `user_ns=true`. Local Docker Desktop Compose sets `CLOFIX_USER_NS=false`, which makes I01 FAIL and is development-only.

## 4. Methodology and limitations

- Same host, one backend at a time. FileVPS uses bundled Ubuntu 24.04. Incus/LXC default to Debian 12 unless you override `INCUS_IMAGE` or `BASE_DISTRO`/`BASE_REL`.
- FileVPS create requires an SSH public key, cgroup limits, and (for networked guests) a `10.231.0.0/16` address plus an SSH host port in 22000–22099. Density tests skip guest networking because only 100 SSH ports exist.
- Protection Mode stays off during the audit so writes inside the guest can be tested. That is not the default for UI-created VPS instances.
- RAM overhead is the host `MemTotal−MemAvailable` delta. Disk is a `df` delta on `STORAGE_PATH`. OverlayFS should show a high OS-share ratio.
- Density is bounded by `DENSITY_MAX` and a memory reserve. It is idle density, not workload density.
- The audit is a configuration/behaviour check, not a kernel exploit assessment. A PASS means that probe did not cross the boundary. Shared-kernel isolation can still fail if the host kernel is buggy.
- Resource probes are bounded. Re-run with `--destructive` only on a throw-away host.
- Run each benchmark at least three times and compare medians before drawing business conclusions.

## 5. How to produce measured results

On a dedicated Linux worker that already has `clofix-worker`, Incus, and/or LXC:

```bash
sudo ./run-compare.sh            # backends that are installed
sudo ./clofix-bench.sh fx
sudo ./clofix-audit.sh fx
python3 make-report.py results results/report.md
```

Do not run density or `--destructive` probes on a production host.

