## 0. Run scope (this collection)

This is a **reduced, non-destructive FileVPS-only** run on the local Docker Desktop Compose worker. It is **not** a dedicated bare-metal compare host and **not** a kernel exploit assessment.

| Item | Value |
| --- | --- |
| Collected | 2026-11-01 07:53–07:55 UTC |
| Host | `clofix-local-worker` (Docker Desktop, kernel `7.0.14-linuxkit`, aarch64) |
| Cores / RAM | 10 / 7934 MB |
| Worker | `clofix-worker 0.1.0`, `CLOFIX_USER_NS=false` (Compose development override) |
| Image | Bundled Ubuntu 24.04 FileVPS rootfs |
| Bench sizes | `N_START=2`, `N_IDLE=2`, `DENSITY_MAX=0`, `SETTLE_S=8` |
| Destructive probes | Not run (`--destructive` off) |
| Incus / LXC | Not installed in this worker — no compare numbers |
| Live fleet left running | `vps-01c09f91ffda`, `vps-1b7ce1e40adf`, `vps-3ab923078227` |
| Agent | `clofix-worker run` stayed up (shared state directory with the local `fx` CLI) |

### How to read these numbers

- Negative idle RAM (`-23.99 MB/VPS`) and negative idle CPU (`-0.22%`) are **host `MemAvailable` / `/proc/stat` jitter**, not a claim that FileVPS uses negative memory. Three customer VPS plus the agent were already on the same worker.
- `projected_idle_density` is `n/a` because measured idle RAM delta was not positive.
- Density count is `0` because `DENSITY_MAX=0` on a worker that already hosts customer VPS. Do not treat that as max packing.
- Isolation FAILs for I01 / I02 / X05 are **expected** with `CLOFIX_USER_NS=false`. Production workers default `user_ns=true`.
- FileVPS guests share the host kernel. They are **not** KVM/QEMU VMs.
- Do not claim Ubuntu/CentOS/Debian/Incus/LXC support from this run. Only FileVPS on linuxkit was measured.
- `N03` matches OverlayFS `lowerdir`/`upperdir` under `/var/lib/clofix-filevps`. That is the guest's own root overlay, not a leaked `docker.sock`.
- `F02` `/tmp` and `/var/tmp` without a sticky bit is a rootfs image issue, not a FileVPS engine escape.
- `O03` `localhost.localdomain` means `--hostname` did not land in `/etc/hostname` for these audit guests.
- `R01`–`R03` FAIL/WARN means the guest could not see `pids.max` / `memory.max` / `cpu.max`. That does not prove the worker skipped host cgroup limits; the probe reads those files from inside the VPS.
